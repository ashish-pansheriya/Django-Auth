from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import databank, image_form, imageform
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView

from django.core.files.storage import FileSystemStorage

# Create your views here.
def home(request):
    users = {
        'post': databank.objects.all()
    }

    return render(request, 'home.html', users)

class PostListView(ListView):
    model = databank
    template_name = 'home.html'
    context_object_name = 'post' #it takes object in post for
    ordering = ['-date_posted']

class PostDetailView(DetailView):
    model = databank
    template_name = 'post_detail.html'

class PostCreateView(LoginRequiredMixin, CreateView ):
    model = databank
    fields = ['title', 'content','image2']
    template_name = 'post_form.html'

    def form_valid(self, form):
        form.instance.author = self.request.user #login must be required to run function with author
        return super().form_valid(form)

def post_ad(request):
    return render(request, 'post_ad.html')

class PostUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView ): # prevent from unauthorised update
    model = databank
    fields = ['title', 'content']
    template_name = 'post_form.html'

    def form_valid(self, form):
        form.instance.author = self.request.user #login must be required to run function with author
        return super().form_valid(form)

    def test_func(self):
        post = self.get_object()
        if self.request.user == post.author:
            return True
        return False


class PostDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView ): # prevent from unauthorised update
    model = databank
    template_name = 'post_confirm_delete.html'
    success_url = '/'

    def test_func(self):
        post = self.get_object()
        if self.request.user == post.author:
            return True
        return False






def upload(request):
    if request.method == 'POST':
        form = image_form(request.POST, request.FILES)

        if form.is_valid():
            form.save()
            return redirect('upload')
    else:
        form = image_form()
    return render(request, 'upload.html',{'form':form})






def uploading(request):
    if request.method == 'POST':
        form = imageform(request.POST, request.FILES)
        if form.is_valid():
            form.save()
        return HttpResponse('/uploading done/')
    else:
        form = imageform()

    return render(request, 'uploading.html',{'form':form})
